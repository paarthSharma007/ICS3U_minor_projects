﻿
using var game = new mP7.Game1();
game.Run();
