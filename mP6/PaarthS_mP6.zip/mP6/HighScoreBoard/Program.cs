﻿
using var game = new HighScoreBoard.Game1();
game.Run();
